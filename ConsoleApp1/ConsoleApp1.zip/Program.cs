﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("E");
Console.WriteLine(" L");
Console.WriteLine("  I");
Console.WriteLine("   A");
Console.WriteLine("    S");
Console.WriteLine("      ");
Console.WriteLine("      M");
Console.WriteLine("       I");
Console.WriteLine("        S");
Console.WriteLine("         S");
Console.WriteLine("          A");
Console.WriteLine("           L");
Console.ReadLine();